import { Button, Box, Spinner } from '@chakra-ui/react';
import { useMemo } from 'react';
import { useInfiniteQuery } from 'react-query';

import { Header } from '../components/Header';
import { CardList } from '../components/CardList';
import { api } from '../services/api';
import { Loading } from '../components/Loading';
import { Error } from '../components/Error';

// interface IGetImagesProps{
//   pageParam?: string | null;
// }

interface IImage{
  title: string;
  description: string;
  url: string;
  ts: number;
  id: string;
}

interface IGetImageResponse{
  after: string;
  data: IImage[]
}


export default function Home(): JSX.Element {


  const getImages = async ({pageParam = null}):Promise<IGetImageResponse> => {

    const { data } = await api.get<IGetImageResponse>('/images', {
      params: {
        after: pageParam,
      },
    });

    console.log(data)
    return data;
  }

  

  // const getNextPageParams = async (after = null) => {
  //   console.log(after)
  //   return after
  // }

  const {
    data,
    isLoading,
    isError,
    isFetchingNextPage,
    fetchNextPage,
    hasNextPage,
  } = useInfiniteQuery(
    {
      queryKey: ['images'],
      queryFn: getImages,
      getNextPageParam: lastPage => lastPage.after ?? null
    }, 
    // 'images',
    

    // TODO AXIOS REQUEST WITH PARAM
    // TODO GET AND RETURN NEXT PAGE PARAM
  );

    console.log(hasNextPage);


  const formattedData = useMemo(() => {
    // TODO FORMAT AND FLAT DATA ARRAY
    console.log(data)

    const formatted = data?.pages.flatMap(imageData => {
      return imageData.data.flat()
    })

    return formatted
    

  }, [data]);

  // TODO RENDER LOADING SCREEN

  if(isLoading){
    return <Loading/>
  }

  if (isError) {
    return <Error />;
  }


  
    // <Spinner color='orange.500'/>
    // <h1>carregando</h1>
  

  // TODO RENDER ERROR SCREEN

  return (
    <>
      <Header />

      <Box maxW={1120} px={20} mx="auto" my={20} pb={8}>
        <CardList cards={formattedData} />
        {/* TODO RENDER LOAD MORE BUTTON IF DATA HAS NEXT PAGE */}

        {hasNextPage && (
          <Button onClick={() => fetchNextPage()} disabled={isFetchingNextPage}>{isFetchingNextPage ? 'Carregando...' : 'Carregar mais'}</Button>
        )}
      </Box>
    </>
  );
}
