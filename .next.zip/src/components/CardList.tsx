import { Grid, SimpleGrid, useDisclosure } from '@chakra-ui/react';
import { useState } from 'react';
import { Card } from './Card';
import { ModalViewImage } from './Modal/ViewImage';

interface Card {
  title: string;
  description: string;
  url: string;
  ts: number;
  id: string;
}

interface CardsProps {
  cards: Card[];
}

export function CardList({ cards }: CardsProps): JSX.Element {
  // TODO MODAL USEDISCLOSURE

  
  
  const [viewImage, setViewImage] = useState('')
  const [isModalOpen, setIsModalOpen] = useState(false)
  console.log(viewImage)

  // TODO SELECTED IMAGE URL STATE

  // TODO FUNCTION HANDLE VIEW IMAGE

  // const cards = [...cards]

  const handleModal = (url: string = null) => {

    if(url){
      setViewImage(url)
    }

    setIsModalOpen(!isModalOpen)
  }


  // console.log(cards)
  return (
    <>
    
      {/* TODO CARD GRID */}

      <div>

        <Grid templateColumns='repeat(3, 1fr)' gap='40px' pb={8}>

          {cards?.map(image => {
            return (
              <Card
                key={image.id}
                data={image}
                viewImage={() => handleModal(image.url)}
              />
            );
          })}

        </Grid>
      </div>

      {/* TODO MODALVIEWIMAGE */}
      {
        viewImage && (
          <ModalViewImage
            isOpen={isModalOpen}
            onClose={handleModal}
            imgUrl={viewImage}
          />
          
        )
      }
    </>
  );
}
