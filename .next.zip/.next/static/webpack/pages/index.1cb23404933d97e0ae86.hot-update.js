webpackHotUpdate_N_E("pages/index",{

/***/ "./src/pages/index.tsx":
/*!*****************************!*\
  !*** ./src/pages/index.tsx ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Home; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/regenerator */ "./node_modules/next/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @chakra-ui/react */ "./node_modules/@chakra-ui/react/dist/esm/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-query */ "./node_modules/react-query/es/index.js");
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../components/Header */ "./src/components/Header.tsx");
/* harmony import */ var _components_CardList__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../components/CardList */ "./src/components/CardList.tsx");
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../services/api */ "./src/services/api.ts");
/* harmony import */ var _components_Loading__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../components/Loading */ "./src/components/Loading.tsx");
/* harmony import */ var _components_Error__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../components/Error */ "./src/components/Error.tsx");





var _jsxFileName = "C:\\code\\React-Next\\ignite\\upload-images\\src\\pages\\index.tsx",
    _s = $RefreshSig$();








 // interface IGetImagesProps{
//   pageParam?: string | null;
// }

function Home() {
  _s();

  var getImages = /*#__PURE__*/function () {
    var _ref2 = Object(C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee(_ref) {
      var _ref$pageParam, pageParam, _yield$api$get, data;

      return C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _ref$pageParam = _ref.pageParam, pageParam = _ref$pageParam === void 0 ? null : _ref$pageParam;
              _context.next = 3;
              return _services_api__WEBPACK_IMPORTED_MODULE_8__["api"].get('/images', {
                params: {
                  after: pageParam
                }
              });

            case 3:
              _yield$api$get = _context.sent;
              data = _yield$api$get.data;
              console.log(data);
              return _context.abrupt("return", data);

            case 7:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function getImages(_x) {
      return _ref2.apply(this, arguments);
    };
  }(); // const getNextPageParams = async (after = null) => {
  //   console.log(after)
  //   return after
  // }


  var _useInfiniteQuery = Object(react_query__WEBPACK_IMPORTED_MODULE_5__["useInfiniteQuery"])({
    queryKey: ['images'],
    queryFn: getImages,
    getNextPageParam: function getNextPageParam(lastPage) {
      var _lastPage$after;

      return (_lastPage$after = lastPage.after) !== null && _lastPage$after !== void 0 ? _lastPage$after : null;
    }
  } // 'images',
  // TODO AXIOS REQUEST WITH PARAM
  // TODO GET AND RETURN NEXT PAGE PARAM
  ),
      data = _useInfiniteQuery.data,
      isLoading = _useInfiniteQuery.isLoading,
      isError = _useInfiniteQuery.isError,
      isFetchingNextPage = _useInfiniteQuery.isFetchingNextPage,
      fetchNextPage = _useInfiniteQuery.fetchNextPage,
      hasNextPage = _useInfiniteQuery.hasNextPage;

  console.log(hasNextPage);
  var formattedData = Object(react__WEBPACK_IMPORTED_MODULE_4__["useMemo"])(function () {
    // TODO FORMAT AND FLAT DATA ARRAY
    console.log(data);
    var formatted = data === null || data === void 0 ? void 0 : data.pages.flatMap(function (imageData) {
      return imageData.data.flat();
    });
    return formatted;
  }, [data]); // TODO RENDER LOADING SCREEN

  if (isLoading) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_Loading__WEBPACK_IMPORTED_MODULE_9__["Loading"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 91,
      columnNumber: 12
    }, this);
  }

  if (isError) {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_Error__WEBPACK_IMPORTED_MODULE_10__["Error"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 95,
      columnNumber: 12
    }, this);
  } // <Spinner color='orange.500'/>
  // <h1>carregando</h1>
  // TODO RENDER ERROR SCREEN


  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_Header__WEBPACK_IMPORTED_MODULE_6__["Header"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 108,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_3__["Box"], {
      maxW: 1120,
      px: 20,
      mx: "auto",
      my: 20,
      pb: 8,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_CardList__WEBPACK_IMPORTED_MODULE_7__["CardList"], {
        cards: formattedData
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 111,
        columnNumber: 9
      }, this), hasNextPage && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_3__["Button"], {
        onClick: function onClick() {
          return fetchNextPage();
        },
        disabled: isFetchingNextPage,
        children: isFetchingNextPage ? 'Carregando...' : 'Carregar mais'
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 115,
        columnNumber: 11
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 110,
      columnNumber: 7
    }, this)]
  }, void 0, true);
}

_s(Home, "nYw6AGml1JrbTFyMNTDsbUPeRkY=", false, function () {
  return [react_query__WEBPACK_IMPORTED_MODULE_5__["useInfiniteQuery"]];
});

_c = Home;

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL3BhZ2VzL2luZGV4LnRzeCJdLCJuYW1lcyI6WyJIb21lIiwiZ2V0SW1hZ2VzIiwicGFnZVBhcmFtIiwiYXBpIiwiZ2V0IiwicGFyYW1zIiwiYWZ0ZXIiLCJkYXRhIiwiY29uc29sZSIsImxvZyIsInVzZUluZmluaXRlUXVlcnkiLCJxdWVyeUtleSIsInF1ZXJ5Rm4iLCJnZXROZXh0UGFnZVBhcmFtIiwibGFzdFBhZ2UiLCJpc0xvYWRpbmciLCJpc0Vycm9yIiwiaXNGZXRjaGluZ05leHRQYWdlIiwiZmV0Y2hOZXh0UGFnZSIsImhhc05leHRQYWdlIiwiZm9ybWF0dGVkRGF0YSIsInVzZU1lbW8iLCJmb3JtYXR0ZWQiLCJwYWdlcyIsImZsYXRNYXAiLCJpbWFnZURhdGEiLCJmbGF0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7Q0FHQTtBQUNBO0FBQ0E7O0FBZ0JlLFNBQVNBLElBQVQsR0FBNkI7QUFBQTs7QUFHMUMsTUFBTUMsU0FBUztBQUFBLDJVQUFHO0FBQUE7O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQ0FBUUMsU0FBUixFQUFRQSxTQUFSLCtCQUFvQixJQUFwQjtBQUFBO0FBQUEscUJBRU9DLGlEQUFHLENBQUNDLEdBQUosQ0FBMkIsU0FBM0IsRUFBc0M7QUFDM0RDLHNCQUFNLEVBQUU7QUFDTkMsdUJBQUssRUFBRUo7QUFERDtBQURtRCxlQUF0QyxDQUZQOztBQUFBO0FBQUE7QUFFUkssa0JBRlEsa0JBRVJBLElBRlE7QUFRaEJDLHFCQUFPLENBQUNDLEdBQVIsQ0FBWUYsSUFBWjtBQVJnQiwrQ0FTVEEsSUFUUzs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFIOztBQUFBLG9CQUFUTixTQUFTO0FBQUE7QUFBQTtBQUFBLEtBQWYsQ0FIMEMsQ0FpQjFDO0FBQ0E7QUFDQTtBQUNBOzs7QUFwQjBDLDBCQTZCdENTLG9FQUFnQixDQUNsQjtBQUNFQyxZQUFRLEVBQUUsQ0FBQyxRQUFELENBRFo7QUFFRUMsV0FBTyxFQUFFWCxTQUZYO0FBR0VZLG9CQUFnQixFQUFFLDBCQUFBQyxRQUFRO0FBQUE7O0FBQUEsZ0NBQUlBLFFBQVEsQ0FBQ1IsS0FBYiw2REFBc0IsSUFBdEI7QUFBQTtBQUg1QixHQURrQixDQU1sQjtBQUlBO0FBQ0E7QUFYa0IsR0E3QnNCO0FBQUEsTUF1QnhDQyxJQXZCd0MscUJBdUJ4Q0EsSUF2QndDO0FBQUEsTUF3QnhDUSxTQXhCd0MscUJBd0J4Q0EsU0F4QndDO0FBQUEsTUF5QnhDQyxPQXpCd0MscUJBeUJ4Q0EsT0F6QndDO0FBQUEsTUEwQnhDQyxrQkExQndDLHFCQTBCeENBLGtCQTFCd0M7QUFBQSxNQTJCeENDLGFBM0J3QyxxQkEyQnhDQSxhQTNCd0M7QUFBQSxNQTRCeENDLFdBNUJ3QyxxQkE0QnhDQSxXQTVCd0M7O0FBMkN4Q1gsU0FBTyxDQUFDQyxHQUFSLENBQVlVLFdBQVo7QUFHRixNQUFNQyxhQUFhLEdBQUdDLHFEQUFPLENBQUMsWUFBTTtBQUNsQztBQUNBYixXQUFPLENBQUNDLEdBQVIsQ0FBWUYsSUFBWjtBQUVBLFFBQU1lLFNBQVMsR0FBR2YsSUFBSCxhQUFHQSxJQUFILHVCQUFHQSxJQUFJLENBQUVnQixLQUFOLENBQVlDLE9BQVosQ0FBb0IsVUFBQUMsU0FBUyxFQUFJO0FBQ2pELGFBQU9BLFNBQVMsQ0FBQ2xCLElBQVYsQ0FBZW1CLElBQWYsRUFBUDtBQUNELEtBRmlCLENBQWxCO0FBSUEsV0FBT0osU0FBUDtBQUdELEdBWDRCLEVBVzFCLENBQUNmLElBQUQsQ0FYMEIsQ0FBN0IsQ0E5QzBDLENBMkQxQzs7QUFFQSxNQUFHUSxTQUFILEVBQWE7QUFDWCx3QkFBTyxxRUFBQywyREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQVA7QUFDRDs7QUFFRCxNQUFJQyxPQUFKLEVBQWE7QUFDWCx3QkFBTyxxRUFBQyx3REFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBQVA7QUFDRCxHQW5FeUMsQ0F1RXhDO0FBQ0E7QUFHRjs7O0FBRUEsc0JBQ0U7QUFBQSw0QkFDRSxxRUFBQyx5REFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREYsZUFHRSxxRUFBQyxvREFBRDtBQUFLLFVBQUksRUFBRSxJQUFYO0FBQWlCLFFBQUUsRUFBRSxFQUFyQjtBQUF5QixRQUFFLEVBQUMsTUFBNUI7QUFBbUMsUUFBRSxFQUFFLEVBQXZDO0FBQTJDLFFBQUUsRUFBRSxDQUEvQztBQUFBLDhCQUNFLHFFQUFDLDZEQUFEO0FBQVUsYUFBSyxFQUFFSTtBQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREYsRUFJR0QsV0FBVyxpQkFDVixxRUFBQyx1REFBRDtBQUFRLGVBQU8sRUFBRTtBQUFBLGlCQUFNRCxhQUFhLEVBQW5CO0FBQUEsU0FBakI7QUFBd0MsZ0JBQVEsRUFBRUQsa0JBQWxEO0FBQUEsa0JBQXVFQSxrQkFBa0IsR0FBRyxlQUFILEdBQXFCO0FBQTlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFIRjtBQUFBLGtCQURGO0FBY0Q7O0dBM0Z1QmpCLEk7VUE2QmxCVSw0RDs7O0tBN0JrQlYsSSIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC4xY2IyMzQwNDkzM2Q5N2UwYWU4Ni5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQnV0dG9uLCBCb3gsIFNwaW5uZXIgfSBmcm9tICdAY2hha3JhLXVpL3JlYWN0JztcclxuaW1wb3J0IHsgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlSW5maW5pdGVRdWVyeSB9IGZyb20gJ3JlYWN0LXF1ZXJ5JztcclxuXHJcbmltcG9ydCB7IEhlYWRlciB9IGZyb20gJy4uL2NvbXBvbmVudHMvSGVhZGVyJztcclxuaW1wb3J0IHsgQ2FyZExpc3QgfSBmcm9tICcuLi9jb21wb25lbnRzL0NhcmRMaXN0JztcclxuaW1wb3J0IHsgYXBpIH0gZnJvbSAnLi4vc2VydmljZXMvYXBpJztcclxuaW1wb3J0IHsgTG9hZGluZyB9IGZyb20gJy4uL2NvbXBvbmVudHMvTG9hZGluZyc7XHJcbmltcG9ydCB7IEVycm9yIH0gZnJvbSAnLi4vY29tcG9uZW50cy9FcnJvcic7XHJcblxyXG4vLyBpbnRlcmZhY2UgSUdldEltYWdlc1Byb3Bze1xyXG4vLyAgIHBhZ2VQYXJhbT86IHN0cmluZyB8IG51bGw7XHJcbi8vIH1cclxuXHJcbmludGVyZmFjZSBJSW1hZ2V7XHJcbiAgdGl0bGU6IHN0cmluZztcclxuICBkZXNjcmlwdGlvbjogc3RyaW5nO1xyXG4gIHVybDogc3RyaW5nO1xyXG4gIHRzOiBudW1iZXI7XHJcbiAgaWQ6IHN0cmluZztcclxufVxyXG5cclxuaW50ZXJmYWNlIElHZXRJbWFnZVJlc3BvbnNle1xyXG4gIGFmdGVyOiBzdHJpbmc7XHJcbiAgZGF0YTogSUltYWdlW11cclxufVxyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEhvbWUoKTogSlNYLkVsZW1lbnQge1xyXG5cclxuXHJcbiAgY29uc3QgZ2V0SW1hZ2VzID0gYXN5bmMgKHtwYWdlUGFyYW0gPSBudWxsfSk6UHJvbWlzZTxJR2V0SW1hZ2VSZXNwb25zZT4gPT4ge1xyXG5cclxuICAgIGNvbnN0IHsgZGF0YSB9ID0gYXdhaXQgYXBpLmdldDxJR2V0SW1hZ2VSZXNwb25zZT4oJy9pbWFnZXMnLCB7XHJcbiAgICAgIHBhcmFtczoge1xyXG4gICAgICAgIGFmdGVyOiBwYWdlUGFyYW0sXHJcbiAgICAgIH0sXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zb2xlLmxvZyhkYXRhKVxyXG4gICAgcmV0dXJuIGRhdGE7XHJcbiAgfVxyXG5cclxuICBcclxuXHJcbiAgLy8gY29uc3QgZ2V0TmV4dFBhZ2VQYXJhbXMgPSBhc3luYyAoYWZ0ZXIgPSBudWxsKSA9PiB7XHJcbiAgLy8gICBjb25zb2xlLmxvZyhhZnRlcilcclxuICAvLyAgIHJldHVybiBhZnRlclxyXG4gIC8vIH1cclxuXHJcbiAgY29uc3Qge1xyXG4gICAgZGF0YSxcclxuICAgIGlzTG9hZGluZyxcclxuICAgIGlzRXJyb3IsXHJcbiAgICBpc0ZldGNoaW5nTmV4dFBhZ2UsXHJcbiAgICBmZXRjaE5leHRQYWdlLFxyXG4gICAgaGFzTmV4dFBhZ2UsXHJcbiAgfSA9IHVzZUluZmluaXRlUXVlcnkoXHJcbiAgICB7XHJcbiAgICAgIHF1ZXJ5S2V5OiBbJ2ltYWdlcyddLFxyXG4gICAgICBxdWVyeUZuOiBnZXRJbWFnZXMsXHJcbiAgICAgIGdldE5leHRQYWdlUGFyYW06IGxhc3RQYWdlID0+IGxhc3RQYWdlLmFmdGVyID8/IG51bGxcclxuICAgIH1cclxuICAgIC8vICdpbWFnZXMnLFxyXG5cclxuICBcclxuXHJcbiAgICAvLyBUT0RPIEFYSU9TIFJFUVVFU1QgV0lUSCBQQVJBTVxyXG4gICAgLy8gVE9ETyBHRVQgQU5EIFJFVFVSTiBORVhUIFBBR0UgUEFSQU1cclxuICApO1xyXG5cclxuICAgIGNvbnNvbGUubG9nKGhhc05leHRQYWdlKTtcclxuXHJcblxyXG4gIGNvbnN0IGZvcm1hdHRlZERhdGEgPSB1c2VNZW1vKCgpID0+IHtcclxuICAgIC8vIFRPRE8gRk9STUFUIEFORCBGTEFUIERBVEEgQVJSQVlcclxuICAgIGNvbnNvbGUubG9nKGRhdGEpXHJcblxyXG4gICAgY29uc3QgZm9ybWF0dGVkID0gZGF0YT8ucGFnZXMuZmxhdE1hcChpbWFnZURhdGEgPT4ge1xyXG4gICAgICByZXR1cm4gaW1hZ2VEYXRhLmRhdGEuZmxhdCgpXHJcbiAgICB9KVxyXG5cclxuICAgIHJldHVybiBmb3JtYXR0ZWRcclxuICAgIFxyXG5cclxuICB9LCBbZGF0YV0pO1xyXG5cclxuICAvLyBUT0RPIFJFTkRFUiBMT0FESU5HIFNDUkVFTlxyXG5cclxuICBpZihpc0xvYWRpbmcpe1xyXG4gICAgcmV0dXJuIDxMb2FkaW5nLz5cclxuICB9XHJcblxyXG4gIGlmIChpc0Vycm9yKSB7XHJcbiAgICByZXR1cm4gPEVycm9yIC8+O1xyXG4gIH1cclxuXHJcblxyXG4gIFxyXG4gICAgLy8gPFNwaW5uZXIgY29sb3I9J29yYW5nZS41MDAnLz5cclxuICAgIC8vIDxoMT5jYXJyZWdhbmRvPC9oMT5cclxuICBcclxuXHJcbiAgLy8gVE9ETyBSRU5ERVIgRVJST1IgU0NSRUVOXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8SGVhZGVyIC8+XHJcblxyXG4gICAgICA8Qm94IG1heFc9ezExMjB9IHB4PXsyMH0gbXg9XCJhdXRvXCIgbXk9ezIwfSBwYj17OH0+XHJcbiAgICAgICAgPENhcmRMaXN0IGNhcmRzPXtmb3JtYXR0ZWREYXRhfSAvPlxyXG4gICAgICAgIHsvKiBUT0RPIFJFTkRFUiBMT0FEIE1PUkUgQlVUVE9OIElGIERBVEEgSEFTIE5FWFQgUEFHRSAqL31cclxuXHJcbiAgICAgICAge2hhc05leHRQYWdlICYmIChcclxuICAgICAgICAgIDxCdXR0b24gb25DbGljaz17KCkgPT4gZmV0Y2hOZXh0UGFnZSgpfSBkaXNhYmxlZD17aXNGZXRjaGluZ05leHRQYWdlfT57aXNGZXRjaGluZ05leHRQYWdlID8gJ0NhcnJlZ2FuZG8uLi4nIDogJ0NhcnJlZ2FyIG1haXMnfTwvQnV0dG9uPlxyXG4gICAgICAgICl9XHJcbiAgICAgIDwvQm94PlxyXG4gICAgPC8+XHJcbiAgKTtcclxufVxyXG4iXSwic291cmNlUm9vdCI6IiJ9