webpackHotUpdate_N_E("pages/index",{

/***/ "./src/components/Form/FormAddImage.tsx":
/*!**********************************************!*\
  !*** ./src/components/Form/FormAddImage.tsx ***!
  \**********************************************/
/*! exports provided: FormAddImage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FormAddImage", function() { return FormAddImage; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/regenerator */ "./node_modules/next/node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/next/node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var _chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @chakra-ui/react */ "./node_modules/@chakra-ui/react/dist/esm/index.js");
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-hook-form */ "./node_modules/react-hook-form/dist/index.esm.mjs");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-query */ "./node_modules/react-query/es/index.js");
/* harmony import */ var _services_api__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../services/api */ "./src/services/api.ts");
/* harmony import */ var _Input_FileInput__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../Input/FileInput */ "./src/components/Input/FileInput.tsx");
/* harmony import */ var _Input_TextInput__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../Input/TextInput */ "./src/components/Input/TextInput.tsx");





var _jsxFileName = "C:\\code\\React-Next\\ignite\\upload-images\\src\\components\\Form\\FormAddImage.tsx",
    _s = $RefreshSig$();

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_2__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }








function FormAddImage(_ref) {
  _s();

  var closeModal = _ref.closeModal;

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_6__["useState"])(''),
      imageUrl = _useState[0],
      setImageUrl = _useState[1];

  var _useState2 = Object(react__WEBPACK_IMPORTED_MODULE_6__["useState"])(''),
      localImageUrl = _useState2[0],
      setLocalImageUrl = _useState2[1];

  var toast = Object(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__["useToast"])();
  var acceptedFormatsRegex = /(?:([^:/?#]+):)?(?:([^/?#]*))?([^?#](?:jpeg|gif|png))(?:\?([^#]*))?(?:#(.*))?/g;
  var formValidations = {
    image: {
      required: 'Arquivo obrigatório',
      validate: {
        lessThan10MB: function lessThan10MB(fileList) {
          return fileList[0].size < 10000000 || 'O arquivo deve ser menor que 10MB';
        },
        acceptedFormats: function acceptedFormats(fileList) {
          return acceptedFormatsRegex.test(fileList[0].type) || 'Somente são aceitos arquivos PNG, JPEG e GIF';
        }
      }
    },
    title: {
      required: 'Título obrigatório',
      minLength: {
        value: 2,
        message: 'Mínimo de 2 caracteres'
      },
      maxLength: {
        value: 20,
        message: 'Máximo de 20 caracteres'
      }
    },
    description: {
      required: 'Descrição obrigatória',
      maxLength: {
        value: 65,
        message: 'Máximo de 65 caracteres'
      }
    }
  };
  var queryClient = Object(react_query__WEBPACK_IMPORTED_MODULE_7__["useQueryClient"])();
  var mutation = Object(react_query__WEBPACK_IMPORTED_MODULE_7__["useMutation"])( /*#__PURE__*/function () {
    var _ref2 = Object(C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_3__["default"])( /*#__PURE__*/C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee(image) {
      var response;
      return C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return _services_api__WEBPACK_IMPORTED_MODULE_8__["api"].post('/images', _objectSpread(_objectSpread({}, image), {}, {
                url: imageUrl
              }));

            case 2:
              response = _context.sent;
              console.log(response);
              return _context.abrupt("return", response.data.image);

            case 5:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function (_x) {
      return _ref2.apply(this, arguments);
    };
  }(), {
    onSuccess: function onSuccess() {
      console.log('opaaaaaa');
      queryClient.invalidateQueries('images');
    } // console.log('oi')

  });

  var _useForm = Object(react_hook_form__WEBPACK_IMPORTED_MODULE_5__["useForm"])(),
      register = _useForm.register,
      handleSubmit = _useForm.handleSubmit,
      reset = _useForm.reset,
      formState = _useForm.formState,
      setError = _useForm.setError,
      trigger = _useForm.trigger;

  var errors = formState.errors;

  var onSubmit = /*#__PURE__*/function () {
    var _ref3 = Object(C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_3__["default"])( /*#__PURE__*/C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee2(data) {
      return C_code_React_Next_ignite_upload_images_node_modules_next_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              console.log(data);
              _context2.prev = 1;

              if (imageUrl) {
                _context2.next = 5;
                break;
              }

              toast({
                title: 'Imagem não adicionada',
                description: 'É preciso adicionar e aguardar o upload de uma imagem antes de realizar o cadastro.',
                status: 'warning',
                duration: 4000,
                isClosable: true
              });
              return _context2.abrupt("return");

            case 5:
              _context2.next = 7;
              return mutation.mutateAsync(data);

            case 7:
              toast({
                title: 'Imagem cadastrada',
                description: 'Sua imagem foi cadastrada com sucesso.',
                status: 'success',
                duration: 4000,
                isClosable: true
              });
              console.log(data);
              _context2.next = 14;
              break;

            case 11:
              _context2.prev = 11;
              _context2.t0 = _context2["catch"](1);
              toast({
                title: 'Falha no cadastro',
                description: 'Ocorreu um erro ao tentar cadastrar a sua imagem.',
                status: 'error',
                duration: 4000,
                isClosable: true
              });

            case 14:
              _context2.prev = 14;
              reset();
              setImageUrl('');
              setLocalImageUrl('');
              closeModal();
              return _context2.finish(14);

            case 20:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2, null, [[1, 11, 14, 20]]);
    }));

    return function onSubmit(_x2) {
      return _ref3.apply(this, arguments);
    };
  }();

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__["Box"], {
    as: "form",
    width: "100%",
    onSubmit: handleSubmit(onSubmit),
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__["Stack"], {
      spacing: 4,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Input_FileInput__WEBPACK_IMPORTED_MODULE_9__["FileInput"], _objectSpread({
        setImageUrl: setImageUrl,
        localImageUrl: localImageUrl,
        setLocalImageUrl: setLocalImageUrl,
        setError: setError,
        trigger: trigger,
        error: errors.image
      }, register('image', formValidations.image)), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 129,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Input_TextInput__WEBPACK_IMPORTED_MODULE_10__["TextInput"] // name='title'
      , _objectSpread({
        placeholder: "T\xEDtulo da imagem..." // type='text'
        ,
        error: errors.title
      }, register('title', formValidations.title)), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 139,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Input_TextInput__WEBPACK_IMPORTED_MODULE_10__["TextInput"], _objectSpread({
        placeholder: "Descri\xE7\xE3o da imagem..." // name='description'
        // type=""
        ,
        error: errors.description
      }, register('description', formValidations.description)), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 148,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 128,
      columnNumber: 7
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__["Button"], {
      my: 6,
      isLoading: formState.isSubmitting,
      isDisabled: formState.isSubmitting,
      type: "submit",
      w: "100%",
      py: 6,
      children: "Enviar"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 157,
      columnNumber: 7
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 127,
    columnNumber: 5
  }, this);
}

_s(FormAddImage, "Q1o0UW6nOtofl1xJIyXCN0KMSgY=", false, function () {
  return [_chakra_ui_react__WEBPACK_IMPORTED_MODULE_4__["useToast"], react_query__WEBPACK_IMPORTED_MODULE_7__["useQueryClient"], react_query__WEBPACK_IMPORTED_MODULE_7__["useMutation"], react_hook_form__WEBPACK_IMPORTED_MODULE_5__["useForm"]];
});

_c = FormAddImage;

var _c;

$RefreshReg$(_c, "FormAddImage");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvRm9ybS9Gb3JtQWRkSW1hZ2UudHN4Il0sIm5hbWVzIjpbIkZvcm1BZGRJbWFnZSIsImNsb3NlTW9kYWwiLCJ1c2VTdGF0ZSIsImltYWdlVXJsIiwic2V0SW1hZ2VVcmwiLCJsb2NhbEltYWdlVXJsIiwic2V0TG9jYWxJbWFnZVVybCIsInRvYXN0IiwidXNlVG9hc3QiLCJhY2NlcHRlZEZvcm1hdHNSZWdleCIsImZvcm1WYWxpZGF0aW9ucyIsImltYWdlIiwicmVxdWlyZWQiLCJ2YWxpZGF0ZSIsImxlc3NUaGFuMTBNQiIsImZpbGVMaXN0Iiwic2l6ZSIsImFjY2VwdGVkRm9ybWF0cyIsInRlc3QiLCJ0eXBlIiwidGl0bGUiLCJtaW5MZW5ndGgiLCJ2YWx1ZSIsIm1lc3NhZ2UiLCJtYXhMZW5ndGgiLCJkZXNjcmlwdGlvbiIsInF1ZXJ5Q2xpZW50IiwidXNlUXVlcnlDbGllbnQiLCJtdXRhdGlvbiIsInVzZU11dGF0aW9uIiwiYXBpIiwicG9zdCIsInVybCIsInJlc3BvbnNlIiwiY29uc29sZSIsImxvZyIsImRhdGEiLCJvblN1Y2Nlc3MiLCJpbnZhbGlkYXRlUXVlcmllcyIsInVzZUZvcm0iLCJyZWdpc3RlciIsImhhbmRsZVN1Ym1pdCIsInJlc2V0IiwiZm9ybVN0YXRlIiwic2V0RXJyb3IiLCJ0cmlnZ2VyIiwiZXJyb3JzIiwib25TdWJtaXQiLCJzdGF0dXMiLCJkdXJhdGlvbiIsImlzQ2xvc2FibGUiLCJtdXRhdGVBc3luYyIsImlzU3VibWl0dGluZyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQVlPLFNBQVNBLFlBQVQsT0FBc0U7QUFBQTs7QUFBQSxNQUE5Q0MsVUFBOEMsUUFBOUNBLFVBQThDOztBQUFBLGtCQUMzQ0Msc0RBQVEsQ0FBQyxFQUFELENBRG1DO0FBQUEsTUFDcEVDLFFBRG9FO0FBQUEsTUFDMURDLFdBRDBEOztBQUFBLG1CQUVqQ0Ysc0RBQVEsQ0FBQyxFQUFELENBRnlCO0FBQUEsTUFFcEVHLGFBRm9FO0FBQUEsTUFFckRDLGdCQUZxRDs7QUFJM0UsTUFBTUMsS0FBSyxHQUFHQyxpRUFBUSxFQUF0QjtBQUVBLE1BQU1DLG9CQUFvQixHQUFHLGdGQUE3QjtBQUVBLE1BQU1DLGVBQWUsR0FBRztBQUN0QkMsU0FBSyxFQUFFO0FBQ0xDLGNBQVEsRUFBRSxxQkFETDtBQUVMQyxjQUFRLEVBQUU7QUFDUkMsb0JBQVksRUFBRSxzQkFBQUMsUUFBUTtBQUFBLGlCQUNwQkEsUUFBUSxDQUFDLENBQUQsQ0FBUixDQUFZQyxJQUFaLEdBQW1CLFFBQW5CLElBQStCLG1DQURYO0FBQUEsU0FEZDtBQUdSQyx1QkFBZSxFQUFFLHlCQUFBRixRQUFRO0FBQUEsaUJBQ3ZCTixvQkFBb0IsQ0FBQ1MsSUFBckIsQ0FBMEJILFFBQVEsQ0FBQyxDQUFELENBQVIsQ0FBWUksSUFBdEMsS0FDQSw4Q0FGdUI7QUFBQTtBQUhqQjtBQUZMLEtBRGU7QUFXdEJDLFNBQUssRUFBRTtBQUNMUixjQUFRLEVBQUUsb0JBREw7QUFFTFMsZUFBUyxFQUFFO0FBQUVDLGFBQUssRUFBRSxDQUFUO0FBQVlDLGVBQU8sRUFBRTtBQUFyQixPQUZOO0FBR0xDLGVBQVMsRUFBRTtBQUFFRixhQUFLLEVBQUUsRUFBVDtBQUFhQyxlQUFPLEVBQUU7QUFBdEI7QUFITixLQVhlO0FBZ0J0QkUsZUFBVyxFQUFFO0FBQ1hiLGNBQVEsRUFBRSx1QkFEQztBQUVYWSxlQUFTLEVBQUU7QUFBRUYsYUFBSyxFQUFFLEVBQVQ7QUFBYUMsZUFBTyxFQUFFO0FBQXRCO0FBRkE7QUFoQlMsR0FBeEI7QUFzQkEsTUFBTUcsV0FBVyxHQUFHQyxrRUFBYyxFQUFsQztBQUVBLE1BQU1DLFFBQVEsR0FBR0MsK0RBQVc7QUFBQSwyVUFBQyxpQkFBTWxCLEtBQU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFDSG1CLGlEQUFHLENBQUNDLElBQUosQ0FBUyxTQUFULGtDQUNuQnBCLEtBRG1CO0FBRXRCcUIsbUJBQUcsRUFBRTdCO0FBRmlCLGlCQURHOztBQUFBO0FBQ3JCOEIsc0JBRHFCO0FBTTNCQyxxQkFBTyxDQUFDQyxHQUFSLENBQVlGLFFBQVo7QUFOMkIsK0NBT3BCQSxRQUFRLENBQUNHLElBQVQsQ0FBY3pCLEtBUE07O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBRDs7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQVN2QjtBQUNEMEIsYUFBUyxFQUFFLHFCQUFNO0FBQ2ZILGFBQU8sQ0FBQ0MsR0FBUixDQUFZLFVBQVo7QUFDQVQsaUJBQVcsQ0FBQ1ksaUJBQVosQ0FBOEIsUUFBOUI7QUFHRCxLQU5BLENBT0Q7O0FBUEMsR0FUdUIsQ0FBNUI7O0FBaEMyRSxpQkF3RHpFQywrREFBTyxFQXhEa0U7QUFBQSxNQXVEbkVDLFFBdkRtRSxZQXVEbkVBLFFBdkRtRTtBQUFBLE1BdUR6REMsWUF2RHlELFlBdUR6REEsWUF2RHlEO0FBQUEsTUF1RDNDQyxLQXZEMkMsWUF1RDNDQSxLQXZEMkM7QUFBQSxNQXVEcENDLFNBdkRvQyxZQXVEcENBLFNBdkRvQztBQUFBLE1BdUR6QkMsUUF2RHlCLFlBdUR6QkEsUUF2RHlCO0FBQUEsTUF1RGZDLE9BdkRlLFlBdURmQSxPQXZEZTs7QUFBQSxNQTBEbkVDLE1BMURtRSxHQTBEeERILFNBMUR3RCxDQTBEbkVHLE1BMURtRTs7QUE0RDNFLE1BQU1DLFFBQVE7QUFBQSwyVUFBRyxrQkFBT1gsSUFBUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2ZGLHFCQUFPLENBQUNDLEdBQVIsQ0FBWUMsSUFBWjtBQURlOztBQUFBLGtCQUtUakMsUUFMUztBQUFBO0FBQUE7QUFBQTs7QUFNWEksbUJBQUssQ0FBQztBQUNKYSxxQkFBSyxFQUFFLHVCQURIO0FBRUpLLDJCQUFXLEVBQUUscUZBRlQ7QUFHSnVCLHNCQUFNLEVBQUUsU0FISjtBQUlKQyx3QkFBUSxFQUFFLElBSk47QUFLSkMsMEJBQVUsRUFBRTtBQUxSLGVBQUQsQ0FBTDtBQU5XOztBQUFBO0FBQUE7QUFBQSxxQkFpQlB0QixRQUFRLENBQUN1QixXQUFULENBQXFCZixJQUFyQixDQWpCTzs7QUFBQTtBQW1CYjdCLG1CQUFLLENBQUM7QUFDSmEscUJBQUssRUFBRSxtQkFESDtBQUVKSywyQkFBVyxFQUNULHdDQUhFO0FBSUp1QixzQkFBTSxFQUFFLFNBSko7QUFLSkMsd0JBQVEsRUFBRSxJQUxOO0FBTUpDLDBCQUFVLEVBQUU7QUFOUixlQUFELENBQUw7QUFRQWhCLHFCQUFPLENBQUNDLEdBQVIsQ0FBWUMsSUFBWjtBQTNCYTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQStCYjdCLG1CQUFLLENBQUM7QUFDSmEscUJBQUssRUFBRSxtQkFESDtBQUVKSywyQkFBVyxFQUFFLG1EQUZUO0FBR0p1QixzQkFBTSxFQUFFLE9BSEo7QUFJSkMsd0JBQVEsRUFBRSxJQUpOO0FBS0pDLDBCQUFVLEVBQUU7QUFMUixlQUFELENBQUw7O0FBL0JhO0FBQUE7QUF1Q2JSLG1CQUFLO0FBQ0x0Qyx5QkFBVyxDQUFDLEVBQUQsQ0FBWDtBQUNBRSw4QkFBZ0IsQ0FBQyxFQUFELENBQWhCO0FBQ0FMLHdCQUFVO0FBMUNHOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQUg7O0FBQUEsb0JBQVI4QyxRQUFRO0FBQUE7QUFBQTtBQUFBLEtBQWQ7O0FBOENBLHNCQUNFLHFFQUFDLG9EQUFEO0FBQUssTUFBRSxFQUFDLE1BQVI7QUFBZSxTQUFLLEVBQUMsTUFBckI7QUFBNEIsWUFBUSxFQUFFTixZQUFZLENBQUNNLFFBQUQsQ0FBbEQ7QUFBQSw0QkFDRSxxRUFBQyxzREFBRDtBQUFPLGFBQU8sRUFBRSxDQUFoQjtBQUFBLDhCQUNFLHFFQUFDLDBEQUFEO0FBQ0UsbUJBQVcsRUFBRTNDLFdBRGY7QUFFRSxxQkFBYSxFQUFFQyxhQUZqQjtBQUdFLHdCQUFnQixFQUFFQyxnQkFIcEI7QUFJRSxnQkFBUSxFQUFFc0MsUUFKWjtBQUtFLGVBQU8sRUFBRUMsT0FMWDtBQU1FLGFBQUssRUFBRUMsTUFBTSxDQUFDbkM7QUFOaEIsU0FPTTZCLFFBQVEsQ0FBQyxPQUFELEVBQVU5QixlQUFlLENBQUNDLEtBQTFCLENBUGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURGLGVBV0UscUVBQUMsMkRBQUQsQ0FDRTtBQURGO0FBRUUsbUJBQVcsRUFBQyx3QkFGZCxDQUdFO0FBSEY7QUFLRSxhQUFLLEVBQUVtQyxNQUFNLENBQUMxQjtBQUxoQixTQU1Nb0IsUUFBUSxDQUFDLE9BQUQsRUFBVTlCLGVBQWUsQ0FBQ1UsS0FBMUIsQ0FOZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBWEYsZUFvQkUscUVBQUMsMkRBQUQ7QUFDRSxtQkFBVyxFQUFDLDhCQURkLENBRUU7QUFDQTtBQUhGO0FBSUUsYUFBSyxFQUFFMEIsTUFBTSxDQUFDckI7QUFKaEIsU0FLTWUsUUFBUSxDQUFDLGFBQUQsRUFBZ0I5QixlQUFlLENBQUNlLFdBQWhDLENBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFERixlQThCRSxxRUFBQyx1REFBRDtBQUNFLFFBQUUsRUFBRSxDQUROO0FBRUUsZUFBUyxFQUFFa0IsU0FBUyxDQUFDUyxZQUZ2QjtBQUdFLGdCQUFVLEVBQUVULFNBQVMsQ0FBQ1MsWUFIeEI7QUFJRSxVQUFJLEVBQUMsUUFKUDtBQUtFLE9BQUMsRUFBQyxNQUxKO0FBTUUsUUFBRSxFQUFFLENBTk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUE5QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREY7QUEyQ0Q7O0dBckplcEQsWTtVQUlBUSx5RCxFQTBCTW1CLDBELEVBRUhFLHVELEVBd0JmVSx1RDs7O0tBeERZdkMsWSIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC4zZDhmYTIxNDM3YzYwNDk4NTk4MC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQm94LCBCdXR0b24sIFN0YWNrLCB1c2VUb2FzdCB9IGZyb20gJ0BjaGFrcmEtdWkvcmVhY3QnO1xyXG5pbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSAncmVhY3QtaG9vay1mb3JtJztcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IE11dGF0aW9uLCB1c2VNdXRhdGlvbiwgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdyZWFjdC1xdWVyeSc7XHJcblxyXG5pbXBvcnQgeyBhcGkgfSBmcm9tICcuLi8uLi9zZXJ2aWNlcy9hcGknO1xyXG5pbXBvcnQgeyBGaWxlSW5wdXQgfSBmcm9tICcuLi9JbnB1dC9GaWxlSW5wdXQnO1xyXG5pbXBvcnQgeyBUZXh0SW5wdXQgfSBmcm9tICcuLi9JbnB1dC9UZXh0SW5wdXQnO1xyXG5cclxuaW50ZXJmYWNlIEZvcm1BZGRJbWFnZVByb3BzIHtcclxuICBjbG9zZU1vZGFsOiAoKSA9PiB2b2lkO1xyXG59XHJcblxyXG5pbnRlcmZhY2UgSUNyZWF0ZUltYWdlRm9ybURhdGF7XHJcbiAgaW1hZ2U6IHN0cmluZztcclxuICB0aXRsZTogc3RyaW5nO1xyXG4gIGRlc2NyaXB0aW9uOiBzdHJpbmc7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBGb3JtQWRkSW1hZ2UoeyBjbG9zZU1vZGFsIH06IEZvcm1BZGRJbWFnZVByb3BzKTogSlNYLkVsZW1lbnQge1xyXG4gIGNvbnN0IFtpbWFnZVVybCwgc2V0SW1hZ2VVcmxdID0gdXNlU3RhdGUoJycpO1xyXG4gIGNvbnN0IFtsb2NhbEltYWdlVXJsLCBzZXRMb2NhbEltYWdlVXJsXSA9IHVzZVN0YXRlKCcnKTtcclxuXHJcbiAgY29uc3QgdG9hc3QgPSB1c2VUb2FzdCgpO1xyXG5cclxuICBjb25zdCBhY2NlcHRlZEZvcm1hdHNSZWdleCA9IC8oPzooW146Lz8jXSspOik/KD86KFteLz8jXSopKT8oW14/I10oPzpqcGVnfGdpZnxwbmcpKSg/OlxcPyhbXiNdKikpPyg/OiMoLiopKT8vZztcclxuXHJcbiAgY29uc3QgZm9ybVZhbGlkYXRpb25zID0ge1xyXG4gICAgaW1hZ2U6IHtcclxuICAgICAgcmVxdWlyZWQ6ICdBcnF1aXZvIG9icmlnYXTDs3JpbycsXHJcbiAgICAgIHZhbGlkYXRlOiB7XHJcbiAgICAgICAgbGVzc1RoYW4xME1COiBmaWxlTGlzdCA9PiAoXHJcbiAgICAgICAgICBmaWxlTGlzdFswXS5zaXplIDwgMTAwMDAwMDAgfHwgJ08gYXJxdWl2byBkZXZlIHNlciBtZW5vciBxdWUgMTBNQicpLFxyXG4gICAgICAgIGFjY2VwdGVkRm9ybWF0czogZmlsZUxpc3QgPT4gKFxyXG4gICAgICAgICAgYWNjZXB0ZWRGb3JtYXRzUmVnZXgudGVzdChmaWxlTGlzdFswXS50eXBlKSB8fFxyXG4gICAgICAgICAgJ1NvbWVudGUgc8OjbyBhY2VpdG9zIGFycXVpdm9zIFBORywgSlBFRyBlIEdJRicpLFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIHRpdGxlOiB7XHJcbiAgICAgIHJlcXVpcmVkOiAnVMOtdHVsbyBvYnJpZ2F0w7NyaW8nLFxyXG4gICAgICBtaW5MZW5ndGg6IHsgdmFsdWU6IDIsIG1lc3NhZ2U6ICdNw61uaW1vIGRlIDIgY2FyYWN0ZXJlcycgfSxcclxuICAgICAgbWF4TGVuZ3RoOiB7IHZhbHVlOiAyMCwgbWVzc2FnZTogJ03DoXhpbW8gZGUgMjAgY2FyYWN0ZXJlcycgfSxcclxuICAgIH0sXHJcbiAgICBkZXNjcmlwdGlvbjoge1xyXG4gICAgICByZXF1aXJlZDogJ0Rlc2NyacOnw6NvIG9icmlnYXTDs3JpYScsXHJcbiAgICAgIG1heExlbmd0aDogeyB2YWx1ZTogNjUsIG1lc3NhZ2U6ICdNw6F4aW1vIGRlIDY1IGNhcmFjdGVyZXMnIH0sXHJcbiAgICB9LFxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKTtcclxuXHJcbiAgY29uc3QgbXV0YXRpb24gPSB1c2VNdXRhdGlvbihhc3luYyhpbWFnZTogSUNyZWF0ZUltYWdlRm9ybURhdGEpID0+IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gIGF3YWl0IGFwaS5wb3N0KCcvaW1hZ2VzJywge1xyXG4gICAgICAuLi5pbWFnZSxcclxuICAgICAgdXJsOiBpbWFnZVVybCxcclxuICAgIH0pXHJcblxyXG4gICAgY29uc29sZS5sb2cocmVzcG9uc2UpXHJcbiAgICByZXR1cm4gcmVzcG9uc2UuZGF0YS5pbWFnZVxyXG5cclxuICAgIH0sIHtcclxuICAgICAgb25TdWNjZXNzOiAoKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coJ29wYWFhYWFhJylcclxuICAgICAgICBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcygnaW1hZ2VzJylcclxuXHJcblxyXG4gICAgICB9XHJcbiAgICAgIC8vIGNvbnNvbGUubG9nKCdvaScpXHJcbiAgICB9XHJcbiAgICBcclxuICAgIFxyXG4gIClcclxuXHJcblxyXG4gIGNvbnN0IHsgcmVnaXN0ZXIsIGhhbmRsZVN1Ym1pdCwgcmVzZXQsIGZvcm1TdGF0ZSwgc2V0RXJyb3IsIHRyaWdnZXIgfSA9XHJcbiAgICB1c2VGb3JtPElDcmVhdGVJbWFnZUZvcm1EYXRhPigpO1xyXG5cclxuICBjb25zdCB7IGVycm9ycyB9ID0gZm9ybVN0YXRlO1xyXG5cclxuICBjb25zdCBvblN1Ym1pdCA9IGFzeW5jIChkYXRhOiBJQ3JlYXRlSW1hZ2VGb3JtRGF0YSk6IFByb21pc2U8dm9pZD4gPT4ge1xyXG4gICAgY29uc29sZS5sb2coZGF0YSk7XHJcbiAgICB0cnkge1xyXG4gICAgICAvLyBhd2FpdCBjcmVhdGVJbWFnZS5tdXRhdGVBc3luYyhkYXRhKVxyXG5cclxuICAgICAgaWYoIWltYWdlVXJsKXtcclxuICAgICAgICB0b2FzdCh7XHJcbiAgICAgICAgICB0aXRsZTogJ0ltYWdlbSBuw6NvIGFkaWNpb25hZGEnLFxyXG4gICAgICAgICAgZGVzY3JpcHRpb246ICfDiSBwcmVjaXNvIGFkaWNpb25hciBlIGFndWFyZGFyIG8gdXBsb2FkIGRlIHVtYSBpbWFnZW0gYW50ZXMgZGUgcmVhbGl6YXIgbyBjYWRhc3Ryby4nLFxyXG4gICAgICAgICAgc3RhdHVzOiAnd2FybmluZycsXHJcbiAgICAgICAgICBkdXJhdGlvbjogNDAwMCxcclxuICAgICAgICAgIGlzQ2xvc2FibGU6IHRydWUsXHJcbiAgICAgICAgfSlcclxuXHJcbiAgICAgICAgcmV0dXJuXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGF3YWl0IG11dGF0aW9uLm11dGF0ZUFzeW5jKGRhdGEpXHJcblxyXG4gICAgICB0b2FzdCh7XHJcbiAgICAgICAgdGl0bGU6ICdJbWFnZW0gY2FkYXN0cmFkYScsXHJcbiAgICAgICAgZGVzY3JpcHRpb246XHJcbiAgICAgICAgICAnU3VhIGltYWdlbSBmb2kgY2FkYXN0cmFkYSBjb20gc3VjZXNzby4nLFxyXG4gICAgICAgIHN0YXR1czogJ3N1Y2Nlc3MnLFxyXG4gICAgICAgIGR1cmF0aW9uOiA0MDAwLFxyXG4gICAgICAgIGlzQ2xvc2FibGU6IHRydWUsXHJcbiAgICAgIH0pO1xyXG4gICAgICBjb25zb2xlLmxvZyhkYXRhKTtcclxuXHJcblxyXG4gICAgfSBjYXRjaCB7XHJcbiAgICAgIHRvYXN0KHtcclxuICAgICAgICB0aXRsZTogJ0ZhbGhhIG5vIGNhZGFzdHJvJyxcclxuICAgICAgICBkZXNjcmlwdGlvbjogJ09jb3JyZXUgdW0gZXJybyBhbyB0ZW50YXIgY2FkYXN0cmFyIGEgc3VhIGltYWdlbS4nLFxyXG4gICAgICAgIHN0YXR1czogJ2Vycm9yJyxcclxuICAgICAgICBkdXJhdGlvbjogNDAwMCxcclxuICAgICAgICBpc0Nsb3NhYmxlOiB0cnVlLFxyXG4gICAgICB9KTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHJlc2V0KCk7XHJcbiAgICAgIHNldEltYWdlVXJsKCcnKTtcclxuICAgICAgc2V0TG9jYWxJbWFnZVVybCgnJyk7XHJcbiAgICAgIGNsb3NlTW9kYWwoKVxyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Qm94IGFzPVwiZm9ybVwiIHdpZHRoPVwiMTAwJVwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXQob25TdWJtaXQpfT5cclxuICAgICAgPFN0YWNrIHNwYWNpbmc9ezR9PlxyXG4gICAgICAgIDxGaWxlSW5wdXRcclxuICAgICAgICAgIHNldEltYWdlVXJsPXtzZXRJbWFnZVVybH1cclxuICAgICAgICAgIGxvY2FsSW1hZ2VVcmw9e2xvY2FsSW1hZ2VVcmx9XHJcbiAgICAgICAgICBzZXRMb2NhbEltYWdlVXJsPXtzZXRMb2NhbEltYWdlVXJsfVxyXG4gICAgICAgICAgc2V0RXJyb3I9e3NldEVycm9yfVxyXG4gICAgICAgICAgdHJpZ2dlcj17dHJpZ2dlcn1cclxuICAgICAgICAgIGVycm9yPXtlcnJvcnMuaW1hZ2V9XHJcbiAgICAgICAgICB7Li4ucmVnaXN0ZXIoJ2ltYWdlJywgZm9ybVZhbGlkYXRpb25zLmltYWdlKX1cclxuICAgICAgICAvPlxyXG5cclxuICAgICAgICA8VGV4dElucHV0XHJcbiAgICAgICAgICAvLyBuYW1lPSd0aXRsZSdcclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiVMOtdHVsbyBkYSBpbWFnZW0uLi5cIlxyXG4gICAgICAgICAgLy8gdHlwZT0ndGV4dCdcclxuXHJcbiAgICAgICAgICBlcnJvcj17ZXJyb3JzLnRpdGxlfVxyXG4gICAgICAgICAgey4uLnJlZ2lzdGVyKCd0aXRsZScsIGZvcm1WYWxpZGF0aW9ucy50aXRsZSl9XHJcbiAgICAgICAgLz5cclxuXHJcbiAgICAgICAgPFRleHRJbnB1dFxyXG4gICAgICAgICAgcGxhY2Vob2xkZXI9XCJEZXNjcmnDp8OjbyBkYSBpbWFnZW0uLi5cIlxyXG4gICAgICAgICAgLy8gbmFtZT0nZGVzY3JpcHRpb24nXHJcbiAgICAgICAgICAvLyB0eXBlPVwiXCJcclxuICAgICAgICAgIGVycm9yPXtlcnJvcnMuZGVzY3JpcHRpb259XHJcbiAgICAgICAgICB7Li4ucmVnaXN0ZXIoJ2Rlc2NyaXB0aW9uJywgZm9ybVZhbGlkYXRpb25zLmRlc2NyaXB0aW9uKX1cclxuICAgICAgICAvPlxyXG4gICAgICA8L1N0YWNrPlxyXG5cclxuICAgICAgPEJ1dHRvblxyXG4gICAgICAgIG15PXs2fVxyXG4gICAgICAgIGlzTG9hZGluZz17Zm9ybVN0YXRlLmlzU3VibWl0dGluZ31cclxuICAgICAgICBpc0Rpc2FibGVkPXtmb3JtU3RhdGUuaXNTdWJtaXR0aW5nfVxyXG4gICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgIHc9XCIxMDAlXCJcclxuICAgICAgICBweT17Nn1cclxuICAgICAgPlxyXG4gICAgICAgIEVudmlhclxyXG4gICAgICA8L0J1dHRvbj5cclxuICAgIDwvQm94PlxyXG4gICk7XHJcbn1cclxuIl0sInNvdXJjZVJvb3QiOiIifQ==