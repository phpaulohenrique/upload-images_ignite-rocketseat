module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/pages/api/images.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/pages/api/images.ts":
/*!*********************************!*\
  !*** ./src/pages/api/images.ts ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return handler; });
/* harmony import */ var faunadb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! faunadb */ "faunadb");
/* harmony import */ var faunadb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(faunadb__WEBPACK_IMPORTED_MODULE_0__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const {
  query
} = faunadb__WEBPACK_IMPORTED_MODULE_0___default.a;
const client = new faunadb__WEBPACK_IMPORTED_MODULE_0___default.a.Client({
  secret: process.env.FAUNA_API_KEY
});
async function handler(req, res) {
  if (req.method === 'POST') {
    const {
      url,
      title,
      description
    } = req.body;
    return client.query(query.Create(query.Collection('images'), {
      data: {
        title,
        description,
        url
      }
    })).then(() => {
      return res.status(201).json({
        success: true
      });
    }).catch(err => res.status(501).json({
      error: `Sorry something Happened! ${err.message}`
    }));
  }

  if (req.method === 'GET') {
    const {
      after
    } = req.query;

    const queryOptions = _objectSpread({
      size: 6
    }, after && {
      after: query.Ref(query.Collection('images'), after)
    });

    return client.query(query.Map(query.Paginate(query.Documents(query.Collection('images')), queryOptions), query.Lambda('X', query.Get(query.Var('X'))))).then(response => {
      const formattedData = response.data.map(item => _objectSpread(_objectSpread({}, item.data), {}, {
        ts: item.ts,
        id: item.ref.id
      }));
      return res.json({
        data: formattedData,
        after: response.after ? response.after[0].id : null
      });
    }).catch(err => {
      return res.status(400).json(err);
    });
  }

  return res.status(405).json({
    error: `Method '${req.method}' Not Allowed`
  });
}

/***/ }),

/***/ "faunadb":
/*!**************************!*\
  !*** external "faunadb" ***!
  \**************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("faunadb");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BhZ2VzL2FwaS9pbWFnZXMudHMiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiZmF1bmFkYlwiIl0sIm5hbWVzIjpbInF1ZXJ5IiwiZmF1bmEiLCJjbGllbnQiLCJDbGllbnQiLCJzZWNyZXQiLCJwcm9jZXNzIiwiZW52IiwiRkFVTkFfQVBJX0tFWSIsImhhbmRsZXIiLCJyZXEiLCJyZXMiLCJtZXRob2QiLCJ1cmwiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwiYm9keSIsIkNyZWF0ZSIsIkNvbGxlY3Rpb24iLCJkYXRhIiwidGhlbiIsInN0YXR1cyIsImpzb24iLCJzdWNjZXNzIiwiY2F0Y2giLCJlcnIiLCJlcnJvciIsIm1lc3NhZ2UiLCJhZnRlciIsInF1ZXJ5T3B0aW9ucyIsInNpemUiLCJSZWYiLCJNYXAiLCJQYWdpbmF0ZSIsIkRvY3VtZW50cyIsIkxhbWJkYSIsIkdldCIsIlZhciIsInJlc3BvbnNlIiwiZm9ybWF0dGVkRGF0YSIsIm1hcCIsIml0ZW0iLCJ0cyIsImlkIiwicmVmIl0sIm1hcHBpbmdzIjoiOztRQUFBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EsSUFBSTtRQUNKO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7OztRQUdBO1FBQ0E7O1FBRUE7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwwQ0FBMEMsZ0NBQWdDO1FBQzFFO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0Esd0RBQXdELGtCQUFrQjtRQUMxRTtRQUNBLGlEQUFpRCxjQUFjO1FBQy9EOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSx5Q0FBeUMsaUNBQWlDO1FBQzFFLGdIQUFnSCxtQkFBbUIsRUFBRTtRQUNySTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDJCQUEyQiwwQkFBMEIsRUFBRTtRQUN2RCxpQ0FBaUMsZUFBZTtRQUNoRDtRQUNBO1FBQ0E7O1FBRUE7UUFDQSxzREFBc0QsK0RBQStEOztRQUVySDtRQUNBOzs7UUFHQTtRQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZGQTtBQUVBLE1BQU07QUFBRUE7QUFBRixJQUFZQyw4Q0FBbEI7QUFDQSxNQUFNQyxNQUFNLEdBQUcsSUFBSUQsOENBQUssQ0FBQ0UsTUFBVixDQUFpQjtBQUFFQyxRQUFNLEVBQUVDLE9BQU8sQ0FBQ0MsR0FBUixDQUFZQztBQUF0QixDQUFqQixDQUFmO0FBbUJlLGVBQWVDLE9BQWYsQ0FDYkMsR0FEYSxFQUViQyxHQUZhLEVBR0U7QUFDZixNQUFJRCxHQUFHLENBQUNFLE1BQUosS0FBZSxNQUFuQixFQUEyQjtBQUN6QixVQUFNO0FBQUVDLFNBQUY7QUFBT0MsV0FBUDtBQUFjQztBQUFkLFFBQThCTCxHQUFHLENBQUNNLElBQXhDO0FBRUEsV0FBT2IsTUFBTSxDQUNWRixLQURJLENBRUhBLEtBQUssQ0FBQ2dCLE1BQU4sQ0FBYWhCLEtBQUssQ0FBQ2lCLFVBQU4sQ0FBaUIsUUFBakIsQ0FBYixFQUF5QztBQUN2Q0MsVUFBSSxFQUFFO0FBQ0pMLGFBREk7QUFFSkMsbUJBRkk7QUFHSkY7QUFISTtBQURpQyxLQUF6QyxDQUZHLEVBVUpPLElBVkksQ0FVQyxNQUFNO0FBQ1YsYUFBT1QsR0FBRyxDQUFDVSxNQUFKLENBQVcsR0FBWCxFQUFnQkMsSUFBaEIsQ0FBcUI7QUFBRUMsZUFBTyxFQUFFO0FBQVgsT0FBckIsQ0FBUDtBQUNELEtBWkksRUFhSkMsS0FiSSxDQWFFQyxHQUFHLElBQ1JkLEdBQUcsQ0FDQVUsTUFESCxDQUNVLEdBRFYsRUFFR0MsSUFGSCxDQUVRO0FBQUVJLFdBQUssRUFBRyw2QkFBNEJELEdBQUcsQ0FBQ0UsT0FBUTtBQUFsRCxLQUZSLENBZEcsQ0FBUDtBQWtCRDs7QUFFRCxNQUFJakIsR0FBRyxDQUFDRSxNQUFKLEtBQWUsS0FBbkIsRUFBMEI7QUFDeEIsVUFBTTtBQUFFZ0I7QUFBRixRQUFZbEIsR0FBRyxDQUFDVCxLQUF0Qjs7QUFFQSxVQUFNNEIsWUFBWTtBQUNoQkMsVUFBSSxFQUFFO0FBRFUsT0FFWkYsS0FBSyxJQUFJO0FBQUVBLFdBQUssRUFBRTNCLEtBQUssQ0FBQzhCLEdBQU4sQ0FBVTlCLEtBQUssQ0FBQ2lCLFVBQU4sQ0FBaUIsUUFBakIsQ0FBVixFQUFzQ1UsS0FBdEM7QUFBVCxLQUZHLENBQWxCOztBQUtBLFdBQU96QixNQUFNLENBQ1ZGLEtBREksQ0FFSEEsS0FBSyxDQUFDK0IsR0FBTixDQUNFL0IsS0FBSyxDQUFDZ0MsUUFBTixDQUNFaEMsS0FBSyxDQUFDaUMsU0FBTixDQUFnQmpDLEtBQUssQ0FBQ2lCLFVBQU4sQ0FBaUIsUUFBakIsQ0FBaEIsQ0FERixFQUVFVyxZQUZGLENBREYsRUFLRTVCLEtBQUssQ0FBQ2tDLE1BQU4sQ0FBYSxHQUFiLEVBQWtCbEMsS0FBSyxDQUFDbUMsR0FBTixDQUFVbkMsS0FBSyxDQUFDb0MsR0FBTixDQUFVLEdBQVYsQ0FBVixDQUFsQixDQUxGLENBRkcsRUFVSmpCLElBVkksQ0FVQ2tCLFFBQVEsSUFBSTtBQUNoQixZQUFNQyxhQUFhLEdBQUdELFFBQVEsQ0FBQ25CLElBQVQsQ0FBY3FCLEdBQWQsQ0FBa0JDLElBQUksb0NBQ3ZDQSxJQUFJLENBQUN0QixJQURrQztBQUUxQ3VCLFVBQUUsRUFBRUQsSUFBSSxDQUFDQyxFQUZpQztBQUcxQ0MsVUFBRSxFQUFFRixJQUFJLENBQUNHLEdBQUwsQ0FBU0Q7QUFINkIsUUFBdEIsQ0FBdEI7QUFNQSxhQUFPaEMsR0FBRyxDQUFDVyxJQUFKLENBQVM7QUFDZEgsWUFBSSxFQUFFb0IsYUFEUTtBQUVkWCxhQUFLLEVBQUVVLFFBQVEsQ0FBQ1YsS0FBVCxHQUFpQlUsUUFBUSxDQUFDVixLQUFULENBQWUsQ0FBZixFQUFrQmUsRUFBbkMsR0FBd0M7QUFGakMsT0FBVCxDQUFQO0FBSUQsS0FyQkksRUFzQkpuQixLQXRCSSxDQXNCRUMsR0FBRyxJQUFJO0FBQ1osYUFBT2QsR0FBRyxDQUFDVSxNQUFKLENBQVcsR0FBWCxFQUFnQkMsSUFBaEIsQ0FBcUJHLEdBQXJCLENBQVA7QUFDRCxLQXhCSSxDQUFQO0FBeUJEOztBQUVELFNBQU9kLEdBQUcsQ0FBQ1UsTUFBSixDQUFXLEdBQVgsRUFBZ0JDLElBQWhCLENBQXFCO0FBQUVJLFNBQUssRUFBRyxXQUFVaEIsR0FBRyxDQUFDRSxNQUFPO0FBQS9CLEdBQXJCLENBQVA7QUFDRCxDOzs7Ozs7Ozs7OztBQ3RGRCxvQyIsImZpbGUiOiJwYWdlcy9hcGkvaW1hZ2VzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSByZXF1aXJlKCcuLi8uLi9zc3ItbW9kdWxlLWNhY2hlLmpzJyk7XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdHZhciB0aHJldyA9IHRydWU7XG4gXHRcdHRyeSB7XG4gXHRcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG4gXHRcdFx0dGhyZXcgPSBmYWxzZTtcbiBcdFx0fSBmaW5hbGx5IHtcbiBcdFx0XHRpZih0aHJldykgZGVsZXRlIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdO1xuIFx0XHR9XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZ2V0dGVyIH0pO1xuIFx0XHR9XG4gXHR9O1xuXG4gXHQvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSBmdW5jdGlvbihleHBvcnRzKSB7XG4gXHRcdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuIFx0XHR9XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG4gXHR9O1xuXG4gXHQvLyBjcmVhdGUgYSBmYWtlIG5hbWVzcGFjZSBvYmplY3RcbiBcdC8vIG1vZGUgJiAxOiB2YWx1ZSBpcyBhIG1vZHVsZSBpZCwgcmVxdWlyZSBpdFxuIFx0Ly8gbW9kZSAmIDI6IG1lcmdlIGFsbCBwcm9wZXJ0aWVzIG9mIHZhbHVlIGludG8gdGhlIG5zXG4gXHQvLyBtb2RlICYgNDogcmV0dXJuIHZhbHVlIHdoZW4gYWxyZWFkeSBucyBvYmplY3RcbiBcdC8vIG1vZGUgJiA4fDE6IGJlaGF2ZSBsaWtlIHJlcXVpcmVcbiBcdF9fd2VicGFja19yZXF1aXJlX18udCA9IGZ1bmN0aW9uKHZhbHVlLCBtb2RlKSB7XG4gXHRcdGlmKG1vZGUgJiAxKSB2YWx1ZSA9IF9fd2VicGFja19yZXF1aXJlX18odmFsdWUpO1xuIFx0XHRpZihtb2RlICYgOCkgcmV0dXJuIHZhbHVlO1xuIFx0XHRpZigobW9kZSAmIDQpICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgJiYgdmFsdWUuX19lc01vZHVsZSkgcmV0dXJuIHZhbHVlO1xuIFx0XHR2YXIgbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIobnMpO1xuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkobnMsICdkZWZhdWx0JywgeyBlbnVtZXJhYmxlOiB0cnVlLCB2YWx1ZTogdmFsdWUgfSk7XG4gXHRcdGlmKG1vZGUgJiAyICYmIHR5cGVvZiB2YWx1ZSAhPSAnc3RyaW5nJykgZm9yKHZhciBrZXkgaW4gdmFsdWUpIF9fd2VicGFja19yZXF1aXJlX18uZChucywga2V5LCBmdW5jdGlvbihrZXkpIHsgcmV0dXJuIHZhbHVlW2tleV07IH0uYmluZChudWxsLCBrZXkpKTtcbiBcdFx0cmV0dXJuIG5zO1xuIFx0fTtcblxuIFx0Ly8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubiA9IGZ1bmN0aW9uKG1vZHVsZSkge1xuIFx0XHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cbiBcdFx0XHRmdW5jdGlvbiBnZXREZWZhdWx0KCkgeyByZXR1cm4gbW9kdWxlWydkZWZhdWx0J107IH0gOlxuIFx0XHRcdGZ1bmN0aW9uIGdldE1vZHVsZUV4cG9ydHMoKSB7IHJldHVybiBtb2R1bGU7IH07XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsICdhJywgZ2V0dGVyKTtcbiBcdFx0cmV0dXJuIGdldHRlcjtcbiBcdH07XG5cbiBcdC8vIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbFxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5vID0gZnVuY3Rpb24ob2JqZWN0LCBwcm9wZXJ0eSkgeyByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcHJvcGVydHkpOyB9O1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCJcIjtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IFwiLi9zcmMvcGFnZXMvYXBpL2ltYWdlcy50c1wiKTtcbiIsImltcG9ydCB7IE5leHRBcGlSZXF1ZXN0LCBOZXh0QXBpUmVzcG9uc2UgfSBmcm9tICduZXh0JztcclxuaW1wb3J0IGZhdW5hIGZyb20gJ2ZhdW5hZGInO1xyXG5cclxuY29uc3QgeyBxdWVyeSB9ID0gZmF1bmE7XHJcbmNvbnN0IGNsaWVudCA9IG5ldyBmYXVuYS5DbGllbnQoeyBzZWNyZXQ6IHByb2Nlc3MuZW52LkZBVU5BX0FQSV9LRVkgfSk7XHJcblxyXG5pbnRlcmZhY2UgSW1hZ2VzUXVlcnlSZXNwb25zZSB7XHJcbiAgYWZ0ZXI/OiB7XHJcbiAgICBpZDogc3RyaW5nO1xyXG4gIH07XHJcbiAgZGF0YToge1xyXG4gICAgZGF0YToge1xyXG4gICAgICB0aXRsZTogc3RyaW5nO1xyXG4gICAgICBkZXNjcmlwdGlvbjogc3RyaW5nO1xyXG4gICAgICB1cmw6IHN0cmluZztcclxuICAgIH07XHJcbiAgICB0czogbnVtYmVyO1xyXG4gICAgcmVmOiB7XHJcbiAgICAgIGlkOiBzdHJpbmc7XHJcbiAgICB9O1xyXG4gIH1bXTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gaGFuZGxlcihcclxuICByZXE6IE5leHRBcGlSZXF1ZXN0LFxyXG4gIHJlczogTmV4dEFwaVJlc3BvbnNlXHJcbik6IFByb21pc2U8dm9pZD4ge1xyXG4gIGlmIChyZXEubWV0aG9kID09PSAnUE9TVCcpIHtcclxuICAgIGNvbnN0IHsgdXJsLCB0aXRsZSwgZGVzY3JpcHRpb24gfSA9IHJlcS5ib2R5O1xyXG5cclxuICAgIHJldHVybiBjbGllbnRcclxuICAgICAgLnF1ZXJ5KFxyXG4gICAgICAgIHF1ZXJ5LkNyZWF0ZShxdWVyeS5Db2xsZWN0aW9uKCdpbWFnZXMnKSwge1xyXG4gICAgICAgICAgZGF0YToge1xyXG4gICAgICAgICAgICB0aXRsZSxcclxuICAgICAgICAgICAgZGVzY3JpcHRpb24sXHJcbiAgICAgICAgICAgIHVybCxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfSlcclxuICAgICAgKVxyXG4gICAgICAudGhlbigoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIHJlcy5zdGF0dXMoMjAxKS5qc29uKHsgc3VjY2VzczogdHJ1ZSB9KTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKGVyciA9PlxyXG4gICAgICAgIHJlc1xyXG4gICAgICAgICAgLnN0YXR1cyg1MDEpXHJcbiAgICAgICAgICAuanNvbih7IGVycm9yOiBgU29ycnkgc29tZXRoaW5nIEhhcHBlbmVkISAke2Vyci5tZXNzYWdlfWAgfSlcclxuICAgICAgKTtcclxuICB9XHJcblxyXG4gIGlmIChyZXEubWV0aG9kID09PSAnR0VUJykge1xyXG4gICAgY29uc3QgeyBhZnRlciB9ID0gcmVxLnF1ZXJ5O1xyXG5cclxuICAgIGNvbnN0IHF1ZXJ5T3B0aW9ucyA9IHtcclxuICAgICAgc2l6ZTogNixcclxuICAgICAgLi4uKGFmdGVyICYmIHsgYWZ0ZXI6IHF1ZXJ5LlJlZihxdWVyeS5Db2xsZWN0aW9uKCdpbWFnZXMnKSwgYWZ0ZXIpIH0pLFxyXG4gICAgfTtcclxuXHJcbiAgICByZXR1cm4gY2xpZW50XHJcbiAgICAgIC5xdWVyeTxJbWFnZXNRdWVyeVJlc3BvbnNlPihcclxuICAgICAgICBxdWVyeS5NYXAoXHJcbiAgICAgICAgICBxdWVyeS5QYWdpbmF0ZShcclxuICAgICAgICAgICAgcXVlcnkuRG9jdW1lbnRzKHF1ZXJ5LkNvbGxlY3Rpb24oJ2ltYWdlcycpKSxcclxuICAgICAgICAgICAgcXVlcnlPcHRpb25zXHJcbiAgICAgICAgICApLFxyXG4gICAgICAgICAgcXVlcnkuTGFtYmRhKCdYJywgcXVlcnkuR2V0KHF1ZXJ5LlZhcignWCcpKSlcclxuICAgICAgICApXHJcbiAgICAgIClcclxuICAgICAgLnRoZW4ocmVzcG9uc2UgPT4ge1xyXG4gICAgICAgIGNvbnN0IGZvcm1hdHRlZERhdGEgPSByZXNwb25zZS5kYXRhLm1hcChpdGVtID0+ICh7XHJcbiAgICAgICAgICAuLi5pdGVtLmRhdGEsXHJcbiAgICAgICAgICB0czogaXRlbS50cyxcclxuICAgICAgICAgIGlkOiBpdGVtLnJlZi5pZCxcclxuICAgICAgICB9KSk7XHJcblxyXG4gICAgICAgIHJldHVybiByZXMuanNvbih7XHJcbiAgICAgICAgICBkYXRhOiBmb3JtYXR0ZWREYXRhLFxyXG4gICAgICAgICAgYWZ0ZXI6IHJlc3BvbnNlLmFmdGVyID8gcmVzcG9uc2UuYWZ0ZXJbMF0uaWQgOiBudWxsLFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goZXJyID0+IHtcclxuICAgICAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDApLmpzb24oZXJyKTtcclxuICAgICAgfSk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gcmVzLnN0YXR1cyg0MDUpLmpzb24oeyBlcnJvcjogYE1ldGhvZCAnJHtyZXEubWV0aG9kfScgTm90IEFsbG93ZWRgIH0pO1xyXG59XHJcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImZhdW5hZGJcIik7Il0sInNvdXJjZVJvb3QiOiIifQ==